
### Expected behavior (预期行为)


### Actual behavior (实际行为)


### Steps to reproduce the behavior (重现步骤)


### NexT Informations

Add the  ✔  sign before an item which is affected by this behavior.

NexT Version:

  -  Master
  -  Latest Release
  -  Old version - 

NexT Scheme:
  -  All schemes
  -  Muse
  -  Mist
  -  Pisces

### Other Informations (Like Browser, System, Screenshots)


